
Flask-WebTest
-------------

Provides a set of utilities to ease testing Flask applications with WebTest.

Links
`````

* `documentation <http://flask-webtest.readthedocs.org/en/latest/>`_
* `development version
  <http://github.com/aromanovich/flask-webtest/zipball/master#egg=Flask-WebTest-dev>`_


